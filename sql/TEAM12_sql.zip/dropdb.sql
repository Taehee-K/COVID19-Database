drop tables policy;
drop tables time_cases;
drop tables confirmed_ethnicity;
drop tables confirmed_gender;
drop tables region_info;
drop tables confirmed_world;
