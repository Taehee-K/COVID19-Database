/* database schema 생성 */

show databases;

create database team12;
use team12;

