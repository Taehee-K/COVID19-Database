create table users(
    idUsers int(11) auto_increment primary key not null,
    uidUsers tinytext not null,
    emailUsers tinytext not null,
    pwdUsers longtext not null
);